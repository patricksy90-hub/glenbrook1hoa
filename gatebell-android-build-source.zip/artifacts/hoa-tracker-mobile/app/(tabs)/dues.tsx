import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, Pressable } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { useListMyDues } from '@workspace/api-client-react';
import { Surface } from '@/components/Surface';
import { formatCurrency, formatDate } from '@/lib/format';
import { LoadingState, ErrorState, EmptyState } from '@/components/ScreenState';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function DuesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data, isLoading, error, refetch } = useListMyDues();
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'paid' | 'overdue'>('all');

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  if (isLoading && !refreshing) return <LoadingState />;
  if (error && !data) return <ErrorState onRetry={refetch} />;

  const filteredData = (data || []).filter(item => {
    if (filter === 'all') return true;
    return item.status === filter;
  });

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={[styles.filterScroll, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        {['all', 'pending', 'paid', 'overdue'].map((f) => (
          <Pressable 
            key={f} 
            style={[styles.filterBtn, filter === f && { backgroundColor: colors.secondary, borderRadius: colors.radius }]}
            onPress={() => setFilter(f as 'all' | 'pending' | 'paid' | 'overdue')}
          >
            <Text style={[styles.filterText, { color: filter === f ? colors.foreground : colors.mutedForeground }]}>
              {f.toUpperCase()}
            </Text>
          </Pressable>
        ))}
      </View>
      <FlatList
        data={filteredData}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 100 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
        ListEmptyComponent={<EmptyState message="No dues found." icon="check-circle" />}
        renderItem={({ item }) => (
          <Surface style={styles.card} elevated>
            <View style={styles.header}>
              <Text style={[styles.period, { color: colors.foreground }]}>{item.period}</Text>
              <Text style={[styles.amount, { color: colors.foreground }]}>{formatCurrency(item.amount)}</Text>
            </View>
            <View style={styles.details}>
              <Text style={[styles.date, { color: colors.mutedForeground }]}>
                Due {formatDate(item.dueDate)}
              </Text>
              <View style={[styles.badge, 
                item.status === 'paid' ? { backgroundColor: colors.primary + '20' } :
                item.status === 'overdue' ? { backgroundColor: colors.destructive + '20' } :
                { backgroundColor: colors.accent }
              ]}>
                <Text style={[styles.badgeText, 
                  item.status === 'paid' ? { color: colors.primary } :
                  item.status === 'overdue' ? { color: colors.destructive } :
                  { color: colors.accentForeground }
                ]}>
                  {item.status.toUpperCase()}
                </Text>
              </View>
            </View>
          </Surface>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  filterScroll: { flexDirection: 'row', padding: 8, borderBottomWidth: 1, gap: 4 },
  filterBtn: { paddingHorizontal: 16, paddingVertical: 8, justifyContent: 'center' },
  filterText: { fontFamily: 'DMSans_600SemiBold', fontSize: 12, letterSpacing: 0.5 },
  card: { padding: 16, marginBottom: 12 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  period: { fontFamily: 'Outfit_600SemiBold', fontSize: 16 },
  amount: { fontFamily: 'Outfit_700Bold', fontSize: 18 },
  details: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  date: { fontFamily: 'DMSans_400Regular', fontSize: 14 },
  badge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 16 },
  badgeText: { fontFamily: 'DMSans_700Bold', fontSize: 10, letterSpacing: 0.5 },
});
