import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Image } from 'expo-image';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';
import { Surface } from '@/components/Surface';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function IdScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  if (!user) return null;

  return (
    <ScrollView 
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 24, paddingBottom: insets.bottom + 100, alignItems: 'center' }}
    >
      <Surface style={styles.idCard} elevated>
        <View style={[styles.cardHeader, { backgroundColor: colors.primary }]}>
          <Text style={[styles.hoaName, { color: colors.primaryForeground }]}>Glenbrook 1 HOA</Text>
          <Text style={[styles.idTitle, { color: colors.primaryForeground }]}>COMMUNITY ID</Text>
        </View>
        <View style={styles.cardBody}>
          <View style={[styles.photoPlaceholder, { backgroundColor: colors.muted }]}>
            <Image 
              source={require('@/assets/images/icon.png')} 
              style={{ width: 60, height: 60, opacity: 0.2 }} 
              contentFit="contain"
            />
          </View>
          <View style={styles.info}>
            <Text style={[styles.name, { color: colors.foreground }]}>
              {user.firstName} {user.lastName}
            </Text>
            
            <View style={[styles.roleBadge, { backgroundColor: colors.secondary, borderRadius: colors.radius }]}>
              <Text style={[styles.roleText, { color: colors.secondaryForeground }]}>
                {user.designation ? user.designation.replace('_', ' ').toUpperCase() : 
                 user.role === 'owner' ? 'HOMEOWNER' : 
                 user.role === 'renter' ? 'RENTER' : 'RESIDENT'}
              </Text>
            </View>

            <View style={styles.detailsGrid}>
              <View style={styles.detailItem}>
                <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Block</Text>
                <Text style={[styles.detailValue, { color: colors.foreground }]}>{user.blockNumber || '--'}</Text>
              </View>
              <View style={styles.detailItem}>
                <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Lot</Text>
                <Text style={[styles.detailValue, { color: colors.foreground }]}>{user.lotNumber || '--'}</Text>
              </View>
            </View>
            <View style={styles.detailItemRow}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Street</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]}>{user.streetName || '--'}</Text>
            </View>
            <View style={styles.detailItemRow}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Member No.</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]}>{user.id.toString().padStart(6, '0')}</Text>
            </View>
          </View>
        </View>
        <View style={[styles.cardFooter, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
          <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
            This digital ID is for community identification purposes only and is non-transferable.
          </Text>
        </View>
      </Surface>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  idCard: { width: '100%', maxWidth: 400, borderRadius: 16, overflow: 'hidden' },
  cardHeader: { padding: 16, alignItems: 'center' },
  hoaName: { fontFamily: 'Outfit_700Bold', fontSize: 20 },
  idTitle: { fontFamily: 'DMSans_500Medium', fontSize: 12, letterSpacing: 2, marginTop: 4, opacity: 0.9 },
  cardBody: { padding: 24, flexDirection: 'row', gap: 20 },
  photoPlaceholder: { width: 100, height: 130, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  info: { flex: 1 },
  name: { fontFamily: 'Outfit_700Bold', fontSize: 22, marginBottom: 8 },
  roleBadge: { paddingHorizontal: 8, paddingVertical: 4, alignSelf: 'flex-start', marginBottom: 16 },
  roleText: { fontFamily: 'DMSans_700Bold', fontSize: 10, letterSpacing: 0.5 },
  detailsGrid: { flexDirection: 'row', gap: 16, marginBottom: 8 },
  detailItem: { flex: 1 },
  detailItemRow: { marginBottom: 8 },
  detailLabel: { fontFamily: 'DMSans_500Medium', fontSize: 11, textTransform: 'uppercase', marginBottom: 2 },
  detailValue: { fontFamily: 'DMSans_600SemiBold', fontSize: 14 },
  cardFooter: { padding: 16, borderTopWidth: 1 },
  footerText: { fontFamily: 'DMSans_400Regular', fontSize: 11, textAlign: 'center', lineHeight: 16 },
});
