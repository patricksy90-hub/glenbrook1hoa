import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { getIdBadge, buildIdNumber } from '@workspace/designation';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const HOA_NAME = 'Glenbrook 1 HOA';
const HOA_ADDRESS = 'Brgy. Pasong Camachile 1, General Trias, Cavite';
const STRIPE_TEAL = '#00838f';
const STRIPE_ORANGE = '#f57f17';
const STRIPE_PINK = '#c2185b';
const NAVY = '#1a2472';

export default function IdScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [side, setSide] = useState<'front' | 'back'>('front');

  if (!user) return null;

  const idUser = user as typeof user & { photo?: string | null };
  const photoUri = idUser.photo
    ? idUser.photo.startsWith('data:')
      ? idUser.photo
      : `data:image/jpeg;base64,${idUser.photo}`
    : null;
  const badge = getIdBadge(user);
  const idNumber = buildIdNumber(user.id, user.role, user.createdAt);
  const memberYearValue = new Date(user.createdAt).getFullYear();
  const memberYear = Number.isFinite(memberYearValue) ? memberYearValue : new Date().getFullYear();
  const fullName = [
    `${user.lastName},`,
    user.firstName,
    user.middleName ? `${user.middleName[0]}.` : '',
  ].filter(Boolean).join(' ');
  const blockLot = user.blockNumber && user.lotNumber
    ? `Block ${user.blockNumber} · Lot ${user.lotNumber}`
    : '—';
  const fullAddress = user.blockNumber && user.lotNumber
    ? `Block ${user.blockNumber}, Lot ${user.lotNumber}${user.streetName ? `, ${user.streetName}` : ''}, ${HOA_ADDRESS}`
    : `Glenbrook 1, ${HOA_ADDRESS}`;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={[styles.page, { paddingBottom: insets.bottom + 100 }]}
    >
      <View style={styles.pageHeader}>
        <Text style={[styles.title, { color: colors.foreground }]}>My Resident ID</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Your Glenbrook 1 HOA identification card
        </Text>
      </View>

      <View style={styles.sidePicker} accessibilityRole="tablist">
        {(['front', 'back'] as const).map((cardSide) => {
          const selected = side === cardSide;
          return (
            <Pressable
              key={cardSide}
              accessibilityRole="tab"
              accessibilityState={{ selected }}
              onPress={() => setSide(cardSide)}
              style={[
                styles.sideButton,
                selected && styles.selectedSideButton,
              ]}
            >
              <Text style={[styles.sideButtonText, selected && styles.selectedSideButtonText]}>
                {cardSide === 'front' ? 'Front' : 'Back'}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {side === 'front' ? (
        <View style={styles.idCard} testID="resident-id-card-front">
          <View style={styles.cardHeader}>
            <Text style={styles.cardHeaderText} numberOfLines={1}>
              {HOA_NAME} · Resident ID
            </Text>
          </View>
          <View style={styles.cardBody}>
            <CommunityStripe />
            <View style={styles.frontContent}>
              {photoUri ? (
                <Image
                  source={{ uri: photoUri }}
                  style={styles.photo}
                  contentFit="contain"
                  accessibilityLabel="Resident photo"
                />
              ) : (
                <View style={[styles.photo, styles.noPhoto]}>
                  <Text style={styles.noPhotoText}>NO PHOTO</Text>
                </View>
              )}

              <View style={styles.nameBlock}>
                <Text style={styles.fieldLabel}>Resident Name</Text>
                <Text style={styles.residentName} numberOfLines={2}>{fullName}</Text>
                <Text style={styles.blockLot}>{blockLot}</Text>
              </View>

              <View>
                <Text style={styles.fieldLabel}>Designation / Role</Text>
                <View style={[styles.roleBadge, { backgroundColor: badge.bg }]}>
                  <Text style={styles.roleText}>{badge.label.toUpperCase()}</Text>
                </View>
              </View>

              <View>
                <Text style={styles.fieldLabel}>System Tracking Number</Text>
                <Text style={styles.trackingNumber} numberOfLines={1}>{idNumber}</Text>
              </View>

              <Image
                source={require('@/assets/images/icon.png')}
                style={styles.cornerLogo}
                contentFit="contain"
                accessibilityLabel={`${HOA_NAME} logo`}
              />
            </View>
          </View>
          <View style={styles.cardFooter}>
            <Text style={styles.cardFooterText}>{HOA_NAME} · GL1</Text>
          </View>
        </View>
      ) : (
        <View style={[styles.idCard, styles.backCard]} testID="resident-id-card-back">
          <View style={styles.cardBody}>
            <View style={styles.backContent}>
              <Image
                source={require('@/assets/images/icon.png')}
                style={styles.backLogo}
                contentFit="contain"
                accessibilityLabel={`${HOA_NAME} logo`}
              />
              <Text style={styles.backHoaName}>{HOA_NAME}</Text>
              <Text style={styles.hoaAddress}>{HOA_ADDRESS}</Text>
              <View style={styles.divider} />
              <View style={styles.backSection}>
                <Text style={styles.backSectionTitle}>Property Address Verification:</Text>
                <Text style={styles.backBodyText}>{fullAddress}</Text>
              </View>
              <View style={styles.backSection}>
                <Text style={styles.backSectionTitle}>Return Policy Note:</Text>
                <Text style={styles.backBodyText}>
                  If found, please return to the HOA Administration Office.
                </Text>
              </View>
            </View>
            <CommunityStripe />
          </View>
          <View style={styles.backFooter}>
            <View style={styles.backIdBlock}>
              <Text style={styles.fieldLabel}>ID Number</Text>
              <Text style={styles.trackingNumber} numberOfLines={1}>{idNumber}</Text>
            </View>
            <Text style={styles.memberSince}>Member{'\n'}since {memberYear}</Text>
          </View>
        </View>
      )}

      <View style={[styles.detailsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.detailsTitle, { color: colors.foreground }]}>ID Details</Text>
        <DetailRow label="Resident Name" value={fullName} color={colors.foreground} muted={colors.mutedForeground} />
        <DetailRow label="Designation / Role" value={badge.label} color={colors.foreground} muted={colors.mutedForeground} />
        <DetailRow label="Block & Lot" value={blockLot} color={colors.foreground} muted={colors.mutedForeground} />
        <DetailRow label="Street" value={user.streetName || '—'} color={colors.foreground} muted={colors.mutedForeground} />
        <DetailRow label="System Tracking Number" value={idNumber} color={colors.foreground} muted={colors.mutedForeground} />
      </View>
    </ScrollView>
  );
}

function CommunityStripe() {
  return (
    <View style={styles.stripe}>
      <View style={[styles.stripeBand, { backgroundColor: STRIPE_TEAL }]}>
        <Text style={styles.stripeMark}>G{'\n'}L</Text>
      </View>
      <View style={[styles.orangeBand, { backgroundColor: STRIPE_ORANGE }]} />
      <View style={[styles.stripeBand, { backgroundColor: STRIPE_PINK }]}>
        <Text style={styles.stripeMark}>1</Text>
      </View>
    </View>
  );
}

function DetailRow({
  label,
  value,
  color,
  muted,
}: {
  label: string;
  value: string;
  color: string;
  muted: string;
}) {
  return (
    <View style={styles.detailRow}>
      <Text style={[styles.detailLabel, { color: muted }]}>{label}</Text>
      <Text style={[styles.detailValue, { color }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    paddingHorizontal: 18,
    paddingTop: 20,
    alignItems: 'center',
    gap: 16,
  },
  pageHeader: { width: '100%', maxWidth: 340, gap: 4 },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 24 },
  subtitle: { fontFamily: 'DMSans_400Regular', fontSize: 14 },
  sidePicker: {
    flexDirection: 'row',
    width: '100%',
    maxWidth: 300,
    padding: 4,
    borderRadius: 10,
    backgroundColor: '#e8eaf1',
  },
  sideButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 9,
    borderRadius: 7,
  },
  selectedSideButton: { backgroundColor: '#ffffff', elevation: 2 },
  sideButtonText: { fontFamily: 'DMSans_600SemiBold', color: '#555b6e', fontSize: 14 },
  selectedSideButtonText: { color: NAVY },
  idCard: {
    width: '100%',
    maxWidth: 300,
    aspectRatio: 152 / 240,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: '#ffffff',
    elevation: 7,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.18,
    shadowRadius: 12,
  },
  backCard: { backgroundColor: '#f5f6fa' },
  cardHeader: {
    backgroundColor: NAVY,
    paddingHorizontal: 8,
    paddingVertical: 10,
    alignItems: 'center',
  },
  cardHeaderText: {
    color: '#ffffff',
    fontFamily: 'DMSans_700Bold',
    fontSize: 11,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  cardBody: { flex: 1, flexDirection: 'row', overflow: 'hidden' },
  stripe: { width: 38, flexDirection: 'column', flexShrink: 0 },
  stripeBand: { flex: 4, alignItems: 'center', justifyContent: 'center' },
  orangeBand: { flex: 0.8 },
  stripeMark: {
    color: '#ffffff',
    fontFamily: 'DMSans_700Bold',
    fontSize: 11,
    textAlign: 'center',
    lineHeight: 14,
  },
  frontContent: {
    flex: 1,
    paddingHorizontal: 10,
    paddingTop: 10,
    paddingBottom: 34,
    gap: 8,
    position: 'relative',
    overflow: 'hidden',
  },
  photo: {
    width: '100%',
    height: 112,
    borderRadius: 5,
    backgroundColor: '#eceff1',
  },
  noPhoto: { alignItems: 'center', justifyContent: 'center' },
  noPhotoText: { color: '#78909c', fontFamily: 'DMSans_700Bold', fontSize: 11 },
  nameBlock: { gap: 1 },
  fieldLabel: {
    color: '#888888',
    fontFamily: 'DMSans_600SemiBold',
    fontSize: 8,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  residentName: { color: '#111111', fontFamily: 'Outfit_700Bold', fontSize: 15, lineHeight: 18 },
  blockLot: { color: '#333333', fontFamily: 'DMSans_600SemiBold', fontSize: 10, marginTop: 2 },
  roleBadge: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginTop: 3 },
  roleText: {
    color: '#ffffff',
    fontFamily: 'DMSans_700Bold',
    fontSize: 9,
    letterSpacing: 0.7,
  },
  trackingNumber: {
    color: '#222222',
    fontFamily: 'DMSans_700Bold',
    fontSize: 10,
    marginTop: 2,
  },
  cornerLogo: {
    position: 'absolute',
    right: 3,
    bottom: 0,
    width: 32,
    height: 32,
    opacity: 0.9,
  },
  cardFooter: {
    backgroundColor: NAVY,
    paddingHorizontal: 6,
    paddingVertical: 9,
    alignItems: 'center',
  },
  cardFooterText: {
    color: '#ffffff',
    fontFamily: 'DMSans_700Bold',
    fontSize: 10,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  backContent: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingTop: 12,
    paddingBottom: 8,
    gap: 7,
  },
  backLogo: { width: 48, height: 48 },
  backHoaName: {
    color: NAVY,
    fontFamily: 'Outfit_700Bold',
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 18,
  },
  hoaAddress: { color: '#555555', fontFamily: 'DMSans_400Regular', fontSize: 9, textAlign: 'center', lineHeight: 13 },
  divider: { width: '80%', height: 1, backgroundColor: NAVY, marginVertical: 2 },
  backSection: { width: '100%', gap: 3 },
  backSectionTitle: { color: '#111111', fontFamily: 'DMSans_700Bold', fontSize: 10 },
  backBodyText: { color: '#333333', fontFamily: 'DMSans_400Regular', fontSize: 9, lineHeight: 13 },
  backFooter: {
    borderTopWidth: 1,
    borderTopColor: '#dddddd',
    backgroundColor: '#ffffff',
    paddingHorizontal: 10,
    paddingVertical: 7,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backIdBlock: { flex: 1, gap: 1 },
  memberSince: { color: '#666666', fontFamily: 'DMSans_400Regular', fontSize: 9, textAlign: 'right', lineHeight: 12 },
  detailsCard: {
    width: '100%',
    maxWidth: 340,
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    gap: 12,
  },
  detailsTitle: { fontFamily: 'Outfit_700Bold', fontSize: 17, marginBottom: 2 },
  detailRow: { gap: 3 },
  detailLabel: { fontFamily: 'DMSans_500Medium', fontSize: 10, letterSpacing: 0.4, textTransform: 'uppercase' },
  detailValue: { fontFamily: 'DMSans_600SemiBold', fontSize: 14 },
});
