# GateBell Android test APK

## Status and limits

This is a build procedure and an unexecuted physical-device test checklist, not evidence of push delivery. Configuration readiness alone does not prove Google accepts the private key, the service-account role, device registration, notification delivery, or tap navigation.

The APK is a standalone **internal test build**, signed with Expo's generated test/debug key. It embeds JavaScript and does not need Metro or Expo Go. Do not upload it to Google Play or distribute it to residents as a production release. A production-signed app with the same package may reject installation of this APK as a signature mismatch. Prefer a dedicated test phone; uninstalling an existing app clears its local login and PIN/biometric setup.

## Option 1: GitHub Actions (no Android SDK on your computer)

A private repository is recommended. The user has explicitly approved a public upload for this Android test-build route after being told the mobile build source will be visible online. Upload only the required mobile/shared-client/build sources—not the API server, account data, private configuration files, or service-account key. Connecting GitHub does not itself change repository visibility.

1. Ensure these changes have been merged and synced to your GitHub repository. Nothing here automatically pushes code, runs a remote build, or publishes an app.
2. In the repository, open **Settings → Secrets and variables → Actions → New repository secret**.
3. Add `FIREBASE_ANDROID_CONFIG_JSON` with the complete `google-services.json` text from the same Firebase project used by the API.
   - Replit Secrets do not transfer to GitHub automatically.
   - Do **not** add the server service-account key. It is not needed for an APK.
4. Open **Actions → Android test APK → Run workflow**.
5. Enter your reachable HOA API hostname without `https://`, a port, or a path. Use the intended test backend. Do not guess a published hostname from the Replit app name. A development hostname only works while its backend is awake and reachable from the phone.
6. Run the workflow. When successful, download the `gatebell-android-test-…` artifact. Extract the ZIP to get `gatebell-test.apk` and its non-sensitive build metadata.
7. Transfer the APK to the test phone, allow installation from that source if Android prompts, and install. Disable that installation permission afterward.

When the workflow is not yet present on the default branch, a manual dispatch cannot be relied on to start it. A separate `gatebell-android-test` build branch can instead include the required mobile/shared-client sources and a `.github/gatebell-test-api-hostname.txt` file containing the approved test API hostname. Pushing that exact branch starts the test APK workflow without merging into the main branch. Before SDK installation, the workflow checks the Android client secret and target hostname; it fails explicitly if either is missing or invalid. Each subsequent push to that branch starts another build, so push only when intending to run a test build. No deployment steps are included.

## Option 2: Local Linux/macOS Android SDK build

Requires Node 22, pnpm 10.26.1, Java 17, and the Android SDK with platform 36, build-tools 36.0.0, NDK 27.1.12297006, and CMake 3.22.1. Accept Android SDK licenses. Set `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) and `JAVA_HOME` appropriately.

Configure `FIREBASE_ANDROID_CONFIG_JSON` through your secure local environment manager; do not put JSON or private keys in shell command history. Set `EXPO_PUBLIC_DOMAIN` to the intended reachable HTTPS API hostname only. Optionally set `EXPO_PUBLIC_WEB_PORTAL_URL` to an HTTPS portal URL for web handoffs. From the repository root:

```sh
pnpm --filter @workspace/hoa-tracker-mobile run android:apk
```

The script copies only required mobile/shared-client sources to a private temporary workspace, installs frozen dependencies there, generates native Android files, bundles JavaScript with Gradle, and removes the temporary directory even on failure. Dependency tools and native build processes receive an allowlisted environment, excluding the server key and unrelated Replit secrets.

The result is `generated-artifacts/android/gatebell-test.apk`. Generated files are ignored by Git and excluded from deployment.

Without an Android SDK, `pnpm --filter @workspace/hoa-tracker-mobile run android:preflight` can check dependency installation, native project generation, and the Android JavaScript bundle using the same client configuration and hostname. It explicitly does **not** compile or produce an APK and does not prove delivery. Its temporary files are also removed.

## Phone and backend preparation

1. Use an Android phone with Google Play services and internet access.
2. Confirm the API is running with both Firebase secrets from the same project and FCM HTTP v1 enabled. Its service account needs permission to send FCM messages. Readiness is only a structural check; the first real send checks authorization.
3. Set up a designated GateBell owner/renter contact for a test unit, and an authorized guard with a valid on-duty gate context. Do not use uninvolved residents or send real emergency alerts; coordinate the test with staff.
4. Open the installed APK, sign in fully (including MFA if required), open **GateBell**, and select **Enable background alerts**. Allow Android notification permission. Check the registration feedback. Re-register after reinstalling or changing Firebase projects.
5. In Android app notification settings, ensure **GateBell alerts** is enabled. Record the phone model, Android version, app version/build metadata, backend environment, and any battery restrictions. Start with normal settings rather than hiding an OEM-specific failure by changing battery settings.
6. Keep the API running during every test. Phone USB access to Replit is not required.

## Required physical-device tests — record actual results

Closed means swipe the app away from Recent Apps, not Android Settings → Force stop. Android force-stop suppresses push until the app is manually reopened. Also test screen-locked background delivery on the actual phone.

For each row, generate a fresh event, record send/receipt timestamps and whether the alert appeared/sounded, tap it, and record whether GateBell opened. Do not substitute a Firebase Console test message: that bypasses the actual GateBell recipients, outbox, and message payload.

| Alert | Foreground | Background/Home | Swiped closed |
|---|---|---|---|
| Visitor call created by an on-duty guard for the test unit | Not run | Not run | Not run |
| Requested visitor photo attached by the guard after the contact requests it | Not run | Not run | Not run |
| Coordinated test emergency for the test unit | Not run | Not run | Not run |

For the photo test, request the photo while the call is available, then change app state before the guard attaches it. If the emergency originates from the resident device, generate it first and send the staff status update after changing the resident app state.

Also record these explicit checks:

- [ ] Tapping each of the three notification kinds opens GateBell from background and a cold start.
- [ ] A cold-start tap respects sign-in/MFA/local PIN or biometric unlock before revealing GateBell.
- [ ] Timely **Let in** works for an active pending test call.
- [ ] Leave a fresh call unanswered until its server deadline/countdown expires, then tap any retained notification. There must be no successful admission; a late API decision is rejected with HTTP 409.
- [ ] Never treat an already displayed notification as proof a call remains active. Visitor-call FCM TTL is 25 seconds; late delivery may be discarded. The server deadline decides whether admission is allowed.
- [ ] Record failures and retry only after fixing their cause; configuration checks or an accepted FCM request alone do not count as receipt.

Do not store user identities, login credentials, device push tokens, private keys, visitor photos, or raw notification payloads in test notes. Keep the task incomplete until actual phone results are recorded.
